import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-signup-home',
  templateUrl: './signup-home.component.html',
  styleUrls: ['./signup-home.component.scss']
})
export class SignupHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
