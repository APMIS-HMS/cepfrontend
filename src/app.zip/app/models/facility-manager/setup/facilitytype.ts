export interface FacilityType {
    _id: string;
    name: string;
    facilityClasss: [any];
}
