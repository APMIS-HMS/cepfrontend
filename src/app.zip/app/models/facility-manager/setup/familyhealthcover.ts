export interface FamilyHealthCover {
    _id: string;
    familyPrincipalPersonId: string;
    facilityId: string;
    dependents: any[];
}
