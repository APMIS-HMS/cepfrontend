export interface Title {
    name: string;
    _id: string;
}
