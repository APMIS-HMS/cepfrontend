export interface ClinicModel {
    clinic: any;
    unit: any;
    department: any;
    _id: string;
    clinicLocation: string;
    clinicName: string;
}
