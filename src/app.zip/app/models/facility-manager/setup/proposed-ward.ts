export interface proposedWardModel {
    _id: string,
    minorLocationId: string,
    isAccepted: boolean,
}
