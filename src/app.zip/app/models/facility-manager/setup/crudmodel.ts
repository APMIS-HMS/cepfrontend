export interface CrudModel {
    id: number,
    name: string;
    isChecked: boolean;
}