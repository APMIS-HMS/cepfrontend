export interface Feature {
    _id: string;
    featureId: string;
    accessControlId: string;
    crud: [any];
}
