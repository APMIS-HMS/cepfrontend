export interface Gender {
    _id: string;
    name: string;
}
