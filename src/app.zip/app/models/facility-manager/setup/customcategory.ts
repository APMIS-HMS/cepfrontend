export interface CustomCategory {
    facilityId: string;
    category: string;
    categoryId: string;
    service: string;
    serviceId: string;
    facilityServiceId: string;
    facilityService: any;
    serviceCode: string;
    isGlobal: boolean;
}
