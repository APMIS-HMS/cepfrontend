export interface Presentation {
    _id: string;
    facilityId: string;
    name: string;
    isActive: boolean;
}