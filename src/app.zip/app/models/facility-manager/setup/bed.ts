export interface Bed {
    _id: string;
    name: string;
}