export interface WardDischarge
{
    dischargeTypeId: String;
    Reason: string;
}