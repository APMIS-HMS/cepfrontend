export interface PersonDependant {
    _id: string;
    dependantPersonId: string;
    relationshipId: string;
}
