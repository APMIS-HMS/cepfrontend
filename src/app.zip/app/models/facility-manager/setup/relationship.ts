export interface Relationship {
    name: string;
    _id: string;
}
