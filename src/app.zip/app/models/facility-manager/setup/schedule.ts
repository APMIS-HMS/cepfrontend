export interface Schedule {
    _id: string;
    day: string;
    location: any;
    startTime: Date;
    endTime: Date;
    text: string;
}
