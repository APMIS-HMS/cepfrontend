export interface Country {
    _id: string
    name: string;
    states: [any];
}
