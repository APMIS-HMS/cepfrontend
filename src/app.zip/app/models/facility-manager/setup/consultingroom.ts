export interface ConsultingRoomModel {
    _id: string;
    facilityId: string;
    majorLocationId: string;
    minorLocationId: any;
    rooms: any[];
    capacity: number;
}
