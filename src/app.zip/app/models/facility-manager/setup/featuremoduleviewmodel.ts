import { FeatureModule } from '../../index';
export interface FeatureModuleViewModel extends FeatureModule {
    checked: boolean;
}