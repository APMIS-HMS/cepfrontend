export interface OrderSetTemplate {
    medications: any[];
    investigations: any[];
    procedures: any[];
    nursingCares: any[];
    physicianOrders: any[];
}
