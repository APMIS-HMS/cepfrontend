export interface Profession {
    _id: string;
    name: string;
    caders: any[];
}
