export interface RoomModel {
    _id: string;
    name: string;
    capacity: number;
}
