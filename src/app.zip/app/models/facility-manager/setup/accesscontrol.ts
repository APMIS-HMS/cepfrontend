export interface AccessControl {
    _id: string;
    name: string;
    facilityId: string;
    features: any[];
    featureList: any[];
    isChecked: boolean;
}
