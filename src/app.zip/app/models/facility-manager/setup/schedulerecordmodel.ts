export interface ScheduleRecordModel {
	scheduleType: any;
	clinic: any;
	schedules: any[];
	facilityId: string;
	department: string;
	unit: string;
	_id: any;
}
