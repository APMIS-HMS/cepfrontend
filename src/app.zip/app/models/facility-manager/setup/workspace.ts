export interface WorkSpace {
    _id: string;
    facilityId: string;
    employeeId: any;
    locations: any[];
    isActive: boolean;
    employee?:any;
}
