import { FacilityModule } from './facilitymodule';
export interface ModuleViewModel extends FacilityModule {
    checked: boolean;
}
