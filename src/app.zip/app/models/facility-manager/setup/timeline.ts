export interface Timeline {
    _id: string;
    startTime: Date;
    endTime: Date;
    person: any;
    comment: string;
    label: string;
}
