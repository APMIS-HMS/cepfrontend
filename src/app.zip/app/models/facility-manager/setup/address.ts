export interface Address {
    street: string;
    city: string;
    lga: string;
    state: string;
    country: string;
    landmark: [any];
}
