export interface FacilityModule {
    name: string;
    _id: string;
}
