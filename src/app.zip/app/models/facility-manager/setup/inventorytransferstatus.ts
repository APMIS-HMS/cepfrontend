export interface InventoryTransferStatus {
    _id: string;
    name: string;
}
