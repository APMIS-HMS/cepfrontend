export interface Tag {
    _id: string;
    name: string;
    facilityId: string;
    createdBy: string;
    tagType: string;
    tagDetails: any;
}
