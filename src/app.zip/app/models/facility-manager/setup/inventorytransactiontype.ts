export interface InventoryTransactionType {
    _id: string;
    name: string;
    inorout: string;
}
