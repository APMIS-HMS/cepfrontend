export interface RequisitionProduct {
    _id: string;
    productId: string;
    qty: number;
}