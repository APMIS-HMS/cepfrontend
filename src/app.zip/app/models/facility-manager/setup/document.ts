export interface Document {
    _id?: string;
    document: any,
    createdBy: any,
    createdAt: Date,
    updatedAt: Date
}
