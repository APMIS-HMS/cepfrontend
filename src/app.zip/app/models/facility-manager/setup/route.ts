export interface Route {
    _id: string;
    facilityId: string,
    name: string,
    isActive: boolean
}