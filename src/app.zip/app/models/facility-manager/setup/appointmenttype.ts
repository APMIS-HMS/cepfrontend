export interface AppointmentType {
    _id: string;
    name: string;
}
