export interface Strength {
    _id: string;
    facilityId: string;
    strength: string;
    isActive: boolean;
}