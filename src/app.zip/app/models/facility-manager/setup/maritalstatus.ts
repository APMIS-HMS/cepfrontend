export interface MaritalStatus {
    name: string;
    _id: string;
}
