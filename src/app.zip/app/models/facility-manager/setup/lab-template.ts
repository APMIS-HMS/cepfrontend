export interface LabTemplate {
    _id?: String;
    facilityId?: String;
    investigation: any;
    scopeLevel: any;
    minorLocation: any;
    createdBy: String;
    name: String;
    result: String;
    outcome: String;
    conclusion: String;
    recommendation: String;
}
