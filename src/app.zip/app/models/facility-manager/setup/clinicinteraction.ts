export interface ClinicInteraction {
    _id: string;
    employee: any;
    locationName: string;
    title: string;
    createdAt: Date;
    startAt: Date;
    endAt: Date;
}
