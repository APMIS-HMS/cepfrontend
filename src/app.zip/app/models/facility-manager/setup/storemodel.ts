export interface StoreModel {
    _id: string;
    name: string;
    facilityId: string;
    isChecked: boolean;
}
