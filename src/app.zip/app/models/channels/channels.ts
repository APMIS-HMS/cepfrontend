export interface Channels {
    channels: ChannelNames[]
}

export interface ChannelNames {
    id: string,
    name: string
}

