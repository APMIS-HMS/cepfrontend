export interface OrderStatus {
    _id: string;
    name: string;
}
