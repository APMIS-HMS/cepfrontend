export interface FacilityOwnership {
    _id: string;
    name: string;
}
