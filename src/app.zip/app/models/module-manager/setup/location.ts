export interface Location {
    _id: string;
    name: string;
    shortName?: string;
    description?: string;
}
