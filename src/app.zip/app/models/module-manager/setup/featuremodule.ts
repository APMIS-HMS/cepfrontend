export interface FeatureModule {
    _id: string;
    name: string;
    moduleId: string;
    actions: any;
}
