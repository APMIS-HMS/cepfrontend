export interface MinorLocation {
    _id?: string;
    name: string;
    shortName?: string;
    description?: string;
    locationId: string;
    text?: string;
    isActive:any;
}
