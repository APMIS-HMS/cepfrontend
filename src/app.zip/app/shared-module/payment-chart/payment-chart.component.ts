import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payment-chart',
  templateUrl: './payment-chart.component.html',
  styleUrls: ['./payment-chart.component.scss']
})
export class PaymentChartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
