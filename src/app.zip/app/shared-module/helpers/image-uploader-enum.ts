export enum ImageUploaderEnum {
    PersonProfileImage = 1,
    PatientProfileImage
}
