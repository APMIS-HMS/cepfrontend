import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-med-record-diagnostics',
  templateUrl: './med-record-diagnostics.component.html',
  styleUrls: ['./med-record-diagnostics.component.scss']
})
export class MedRecordDiagnosticsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
