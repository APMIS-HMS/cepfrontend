import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-page-home',
  templateUrl: './home-page-home.component.html',
  styleUrls: ['./home-page-home.component.scss']
})
export class HomePageHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
